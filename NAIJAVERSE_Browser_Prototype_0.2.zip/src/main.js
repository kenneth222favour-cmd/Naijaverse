import * as THREE from 'three';
import './style.css';

const app = document.querySelector('#app');
const loading = document.querySelector('#loading');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bc3d5);
scene.fog = new THREE.Fog(0x9bc3d5, 75, 210);

const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 500);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'low-power' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
app.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xd8edff, 0x56604b, 2.0));
const sun = new THREE.DirectionalLight(0xffedcf, 2.2);
sun.position.set(-35, 65, 25);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -75; sun.shadow.camera.right = 75;
sun.shadow.camera.top = 75; sun.shadow.camera.bottom = -75;
scene.add(sun);

const mat = (color, roughness = 0.9) => new THREE.MeshStandardMaterial({ color, roughness });
const groundMat = mat(0x77856f);
const roadMat = mat(0x303943);
const concreteMat = mat(0xb8b5a8);
const whiteMat = mat(0xf2ead6);
const yellowMat = mat(0xffc02f);
const darkMat = mat(0x1d2832);

function box(w,h,d, material, x,y,z, cast=true) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), material);
  m.position.set(x,y,z); m.castShadow = cast; m.receiveShadow = true; scene.add(m); return m;
}

// Prototype district ground and intersecting streets. Layout is intentionally schematic,
// not a surveyed or geographically accurate Lagos map.
box(240, 0.5, 240, groundMat, 0, -0.35, 0, false);
box(240, 0.12, 18, roadMat, 0, -0.05, 0, false);
box(18, 0.13, 240, roadMat, 0, -0.035, 0, false);
box(240, 0.2, 1.4, concreteMat, 0, 0.05, 9.8, false);
box(240, 0.2, 1.4, concreteMat, 0, 0.05, -9.8, false);
box(1.4, 0.2, 240, concreteMat, 9.8, 0.05, 0, false);
box(1.4, 0.2, 240, concreteMat, -9.8, 0.05, 0, false);

for (let x = -110; x <= 110; x += 8) {
  box(3.5, 0.025, 0.22, yellowMat, x, 0.035, 0, false);
}
for (let z = -110; z <= 110; z += 8) {
  box(0.22, 0.025, 3.5, whiteMat, 0, 0.04, z, false);
}

// Side streets and pavements.
for (const z of [-62, 62]) {
  box(240, 0.1, 9, roadMat, 0, -0.08, z, false);
  box(240, 0.18, 1, concreteMat, 0, 0.02, z - 5.1, false);
  box(240, 0.18, 1, concreteMat, 0, 0.02, z + 5.1, false);
}
for (const x of [-62, 62]) {
  box(9, 0.1, 240, roadMat, x, -0.08, 0, false);
  box(1, 0.18, 240, concreteMat, x - 5.1, 0.02, 0, false);
  box(1, 0.18, 240, concreteMat, x + 5.1, 0.02, 0, false);
}

// Building blocks around the road grid.
const buildingColors = [0xc8b69a, 0xd6d0c0, 0xb9c2bd, 0xc7a58a, 0x9daeb0, 0xe0c99e, 0xaeb6c0];
function makeBuilding(x,z,w,d,h,color,index) {
  const body = box(w,h,d,mat(color),x,h/2,z);
  box(w+0.35,0.35,d+0.35,mat(0x6b7377),x,h+0.15,z);
  const floors = Math.max(2, Math.floor(h/3));
  for(let f=0; f<floors; f++) {
    const y = 1.2 + f*2.6;
    if(y > h-0.3) break;
    for(let side=-1; side<=1; side+=2) {
      const win = new THREE.Mesh(new THREE.BoxGeometry(w*0.13,0.9,0.08), mat(0x344d5a,0.35));
      win.position.set(x+side*w*0.28,y,z+d/2+0.045); scene.add(win);
      win.castShadow = false;
    }
  }
  // Small shopfront awning on selected buildings.
  if(index % 3 === 0) box(w*0.65,0.25,1.5,yellowMat,x,h*0.18,z+d/2+0.7);
}
let seed = 17;
function rand(){ seed = (seed*9301+49297)%233280; return seed/233280; }
let buildingIndex=0;
for (const sx of [-1,1]) for (const sz of [-1,1]) {
  for(let row=0; row<5; row++) for(let col=0; col<5; col++) {
    const x = sx*(18 + col*8.4 + rand()*1.5);
    const z = sz*(18 + row*8.4 + rand()*1.5);
    const w = 5.2 + rand()*2.1, d = 5.2 + rand()*2.1, h = 5 + rand()*18;
    makeBuilding(x,z,w,d,h,buildingColors[Math.floor(rand()*buildingColors.length)],buildingIndex++);
  }
}

// Street lights.
for(let i=-5;i<=5;i++) {
  for(const side of [-1,1]) {
    const x=i*17;
    const z=side*12;
    const pole=new THREE.Mesh(new THREE.CylinderGeometry(.09,.13,5,7),mat(0x42484b));
    pole.position.set(x,2.5,z); scene.add(pole);
    const arm=box(1.4,.12,.12,mat(0x42484b),x+0.55,4.8,z,false);
    const lamp=new THREE.Mesh(new THREE.SphereGeometry(.22,8,8),mat(0xffe6a0));
    lamp.position.set(x+1.1,4.7,z); scene.add(lamp);
  }
}

// A recognizable yellow minibus prop.
function makeBus(x,z,rotation=0) {
  const g=new THREE.Group();
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.5,2.1,5.2),yellowMat); body.position.y=1.25; body.castShadow=true; g.add(body);
  const roof=new THREE.Mesh(new THREE.BoxGeometry(2.35,.55,3.5),mat(0xe8ad24)); roof.position.set(0,2.55,-.15); g.add(roof);
  const glass=mat(0x243b49,.25);
  for(const side of [-1,1]) for(let i=0;i<3;i++){
    const win=new THREE.Mesh(new THREE.BoxGeometry(.04,.65,.85),glass); win.position.set(side*1.26,1.65,.9-i*1.25); g.add(win);
  }
  const front=new THREE.Mesh(new THREE.BoxGeometry(1.5,.65,.05),glass); front.position.set(0,1.8,2.62); g.add(front);
  for(const side of [-1,1]) for(const zz of [-1.7,1.7]){
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.25,12),darkMat);
    wheel.rotation.z=Math.PI/2; wheel.position.set(side*1.28,.55,zz); g.add(wheel);
  }
  g.position.set(x,0,z); g.rotation.y=rotation; scene.add(g); return g;
}
makeBus(15,4,-Math.PI/2);
makeBus(-42,14,Math.PI/2);

// Signage.
const sign = new THREE.Group();
const board = new THREE.Mesh(new THREE.BoxGeometry(8,1.4,.25),mat(0x123c36)); board.position.y=5.2; sign.add(board);
const post1 = new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,.5,8),darkMat); post1.position.set(-2.7,4.25,0); sign.add(post1);
const post2 = post1.clone(); post2.position.x=2.7; sign.add(post2);
sign.position.set(0,0,-15); scene.add(sign);
function label(text, color='#ffffff') {
  const canvas=document.createElement('canvas'); canvas.width=512; canvas.height=128;
  const ctx=canvas.getContext('2d'); ctx.fillStyle=color; ctx.font='bold 62px Arial'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(text,256,64);
  const tex=new THREE.CanvasTexture(canvas);
  const mesh=new THREE.Mesh(new THREE.PlaneGeometry(7.5,1.875),new THREE.MeshBasicMaterial({map:tex,transparent:true}));
  mesh.position.set(0,5.2,.15); sign.add(mesh);
}
label('LAGOS');

// Detailed semi-realistic human player character (procedural prototype model).
// The old capsule placeholder is replaced with a complete human silhouette,
// facial features, layered streetwear, articulated limbs and walk animation.
const player = new THREE.Group();
const skin = new THREE.MeshStandardMaterial({ color: 0x75452f, roughness: 0.78 });
const skinLight = new THREE.MeshStandardMaterial({ color: 0x956044, roughness: 0.76 });
const skinShadow = new THREE.MeshStandardMaterial({ color: 0x553321, roughness: 0.85 });
const shirt = new THREE.MeshStandardMaterial({ color: 0xe6e0d2, roughness: 0.88 });
const overshirt = new THREE.MeshStandardMaterial({ color: 0x176477, roughness: 0.82 });
const shirtDark = new THREE.MeshStandardMaterial({ color: 0x104553, roughness: 0.9 });
const trousers = new THREE.MeshStandardMaterial({ color: 0x252b35, roughness: 0.92 });
const trouserLight = new THREE.MeshStandardMaterial({ color: 0x343b45, roughness: 0.9 });
const shoe = new THREE.MeshStandardMaterial({ color: 0x17191d, roughness: 0.72 });
const sole = new THREE.MeshStandardMaterial({ color: 0xc6c2b8, roughness: 0.9 });
const hair = new THREE.MeshStandardMaterial({ color: 0x171513, roughness: 0.96 });
const eyeWhite = new THREE.MeshStandardMaterial({ color: 0xf0e9df, roughness: 0.5 });
const iris = new THREE.MeshStandardMaterial({ color: 0x24160f, roughness: 0.4 });
const detailDark = new THREE.MeshStandardMaterial({ color: 0x17212a, roughness: 0.7 });
const metal = new THREE.MeshStandardMaterial({ color: 0xb8a16d, metalness: 0.55, roughness: 0.38 });

function ellipsoid(parent, material, x, y, z, sx, sy, sz, segments=20) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, segments, Math.max(12, Math.floor(segments*.7))), material);
  mesh.position.set(x,y,z); mesh.scale.set(sx,sy,sz); mesh.castShadow = true; mesh.receiveShadow = true; parent.add(mesh); return mesh;
}
function cylinderBetween(parent, material, a, b, radiusTop, radiusBottom, segments=12) {
  const av = new THREE.Vector3(...a), bv = new THREE.Vector3(...b);
  const dir = new THREE.Vector3().subVectors(bv,av);
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radiusTop,radiusBottom,dir.length(),segments), material);
  mesh.position.copy(av).add(bv).multiplyScalar(.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());
  mesh.castShadow=true; mesh.receiveShadow=true; parent.add(mesh); return mesh;
}
function capsuleLimb(parent, material, radius, length, y, z=0) {
  const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 5, 12), material);
  mesh.position.set(0,y,z); mesh.castShadow=true; mesh.receiveShadow=true; parent.add(mesh); return mesh;
}

// Pelvis and natural waist.
ellipsoid(player, trousers, 0, .91, 0, .255, .22, .17, 24);
// Shirt torso: tapered waist and broader shoulders, with an undershirt collar.
ellipsoid(player, shirt, 0, 1.27, 0, .295, .39, .19, 28);
ellipsoid(player, overshirt, 0, 1.31, -.018, .315, .34, .205, 28);
ellipsoid(player, overshirt, 0, 1.53, -.005, .355, .16, .205, 28);
ellipsoid(player, shirt, 0, 1.59, .105, .115, .105, .09, 20);
// Overshirt front opening, buttons, chest pockets and seams.
const placket = new THREE.Mesh(new THREE.BoxGeometry(.035,.47,.018), shirtDark); placket.position.set(0,1.31,.207); player.add(placket);
for (let y=1.18; y<=1.49; y+=.105) ellipsoid(player, metal, 0,y,.222,.018,.018,.009,10);
for (const side of [-1,1]) {
  const pocket = new THREE.Mesh(new THREE.BoxGeometry(.105,.115,.018), shirtDark);
  pocket.position.set(side*.19,1.39,.194); player.add(pocket);
  const pocketFlap = new THREE.Mesh(new THREE.BoxGeometry(.12,.035,.022), overshirt);
  pocketFlap.position.set(side*.19,1.46,.202); player.add(pocketFlap);
}
// Neck and head, with jaw and cheek definition.
cylinderBetween(player, skin, [0,1.55,0], [0,1.77,0], .105,.12,16);
ellipsoid(player, skin, 0,1.91,.005,.205,.265,.19,28);
ellipsoid(player, skinLight, 0,1.84,.12,.16,.16,.105,24);
// Ears.
for (const side of [-1,1]) {
  ellipsoid(player, skin, side*.205,1.91,0,.052,.085,.045,16);
  ellipsoid(player, skinShadow, side*.229,1.91,.014,.018,.043,.018,12);
}
// Nose bridge and tip, facing +Z.
ellipsoid(player, skinLight, 0,1.91,.193,.043,.083,.045,16);
ellipsoid(player, skin, 0,1.865,.224,.055,.035,.045,16);
// Eyes, irises, eyelids and brows.
for (const side of [-1,1]) {
  ellipsoid(player, skinShadow, side*.079,1.982,.169,.061,.034,.024,16);
  ellipsoid(player, eyeWhite, side*.079,1.982,.187,.044,.022,.015,16);
  ellipsoid(player, iris, side*.079,1.98,.201,.013,.016,.008,12);
  ellipsoid(player, hair, side*.079,2.026,.183,.055,.014,.018,14);
}
// Mouth and subtle chin line.
const mouth = new THREE.Mesh(new THREE.BoxGeometry(.075,.012,.012), skinShadow); mouth.position.set(0,1.795,.215); player.add(mouth);
ellipsoid(player, skinShadow, 0,1.755,.17,.065,.012,.018,14);
// Short textured low fade: skull cap plus many small curls, kept lightweight.
ellipsoid(player, hair, 0,2.105,-.005,.211,.115,.195,24);
ellipsoid(player, hair, 0,2.075,.13,.19,.075,.095,20);
for (let i=0;i<22;i++) {
  const a=(i/22)*Math.PI*2;
  const curl=ellipsoid(player,hair,Math.cos(a)*.16,2.145+Math.sin(i*2.1)*.012,.0+Math.sin(a)*.145,.035,.035,.035,10);
}
// Hairline fade around temples.
for (const side of [-1,1]) ellipsoid(player,hair,side*.18,2.04,.015,.035,.075,.12,14);

// Articulated arms with elbows, forearms, hands and individual fingers.
const arms=[];
for (const side of [-1,1]) {
  const arm = new THREE.Group(); arm.position.set(side*.34,1.52,0); player.add(arm);
  ellipsoid(arm,overshirt,0,-.09,0,.14,.19,.145,18);
  capsuleLimb(arm,overshirt,.105,.27,-.29,0);
  ellipsoid(arm,overshirt,0,-.46,0,.105,.105,.105,16);
  capsuleLimb(arm,skin,.078,.27,-.64,.005);
  ellipsoid(arm,skin,0,-.81,.015,.075,.09,.065,16);
  // Four fingers and a thumb, all attached to the palm.
  for (let f=0;f<4;f++) {
    const fx=(f-1.5)*.035;
    capsuleLimb(arm,skin,.014,.065,-.91,fx+.015);
  }
  cylinderBetween(arm,skin,[-.065,-.82,.015],[-.105,-.89,.035],.022,.018,8);
  // Cuff and a simple wristwatch on the left arm.
  const cuff = new THREE.Mesh(new THREE.TorusGeometry(.079,.012,6,16),shirt); cuff.rotation.x=Math.PI/2; cuff.position.set(0,-.72,.005); arm.add(cuff);
  if(side===-1){
    const watch = new THREE.Mesh(new THREE.BoxGeometry(.07,.045,.025),detailDark); watch.position.set(0,-.75,.068); arm.add(watch);
    const face = new THREE.Mesh(new THREE.BoxGeometry(.045,.026,.008),metal); face.position.set(0,-.75,.084); arm.add(face);
  }
  arms.push(arm);
}

// Legs are split at the knee so the walk cycle bends naturally.
const legs=[];
for (const side of [-1,1]) {
  const leg = new THREE.Group(); leg.position.set(side*.145,.91,0); player.add(leg);
  capsuleLimb(leg,trousers,.115,.31,-.235,0);
  ellipsoid(leg,trouserLight,0,-.43,0,.12,.105,.125,16);
  capsuleLimb(leg,trousers,.09,.31,-.66,0);
  // Ankle and detailed sneaker, pointing in the +Z travel direction.
  ellipsoid(leg,skin,0,-.84,0,.075,.065,.075,14);
  const sneaker = new THREE.Group(); sneaker.position.set(0,-.91,.075); leg.add(sneaker);
  ellipsoid(sneaker,shoe,0,0,.025,.115,.085,.205,18);
  ellipsoid(sneaker,sole,0,-.058,.04,.118,.025,.205,18);
  const tongue = new THREE.Mesh(new THREE.BoxGeometry(.075,.012,.12),shirt); tongue.position.set(0,.055,.08); sneaker.add(tongue);
  for(let lace=0;lace<3;lace++){
    const line=new THREE.Mesh(new THREE.BoxGeometry(.07,.008,.012),whiteMat); line.position.set(0,.067,.035+lace*.035); sneaker.add(line);
  }
  legs.push(leg);
}
// Small fabric folds and trouser pockets add definition at normal play distance.
for (const side of [-1,1]) {
  const seam = new THREE.Mesh(new THREE.BoxGeometry(.012,.44,.012),trouserLight);
  seam.position.set(side*.16,.59,.17); player.add(seam);
}
player.position.set(0,0,25); scene.add(player);

let yaw=0, pitch=-0.18, distance=8;
const keys={};
const moveTouch={forward:false,back:false,left:false,right:false};
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;});
document.querySelectorAll('[data-move]').forEach(btn=>{
  const key=btn.dataset.move;
  const on=e=>{e.preventDefault();moveTouch[key]=true;};
  const off=e=>{e.preventDefault();moveTouch[key]=false;};
  btn.addEventListener('pointerdown',on); btn.addEventListener('pointerup',off);
  btn.addEventListener('pointerleave',off); btn.addEventListener('pointercancel',off);
});
let dragging=false,lastX=0,lastY=0;
renderer.domElement.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;});
addEventListener('pointerup',()=>dragging=false);
addEventListener('pointermove',e=>{
  if(!dragging)return;
  yaw-=(e.clientX-lastX)*0.005;
  pitch=Math.max(-0.65,Math.min(0.25,pitch+(e.clientY-lastY)*0.003));
  lastX=e.clientX;lastY=e.clientY;
});
renderer.domElement.addEventListener('wheel',e=>{distance=Math.max(5,Math.min(13,distance+e.deltaY*.008));});

const clock=new THREE.Clock();
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.04);
  let forward=(keys.w||keys.arrowup||moveTouch.forward?1:0)-(keys.s||keys.arrowdown||moveTouch.back?1:0);
  let side=(keys.d||keys.arrowright||moveTouch.right?1:0)-(keys.a||keys.arrowleft||moveTouch.left?1:0);
  const moving=Math.abs(forward)+Math.abs(side)>0;
  if(moving){
    const len=Math.hypot(forward,side); forward/=len; side/=len;
    const speed=7.2;
    const dx=(Math.sin(yaw)*forward+Math.cos(yaw)*side)*speed*dt;
    const dz=(Math.cos(yaw)*forward-Math.sin(yaw)*side)*speed*dt;
    player.position.x=THREE.MathUtils.clamp(player.position.x+dx,-112,112);
    player.position.z=THREE.MathUtils.clamp(player.position.z+dz,-112,112);
    player.rotation.y=Math.atan2(dx,dz);
    const phase=performance.now()*.009;
    const step=Math.sin(phase)*.48;
    legs[0].rotation.x=step; legs[1].rotation.x=-step;
    arms[0].rotation.x=-step*.72; arms[1].rotation.x=step*.72;
    player.position.y=Math.abs(Math.sin(phase*2))*.035;
  } else {
    legs[0].rotation.x=0; legs[1].rotation.x=0;
    arms[0].rotation.x=0; arms[1].rotation.x=0;
    player.position.y=THREE.MathUtils.lerp(player.position.y,0,.18);
  }
  const target=new THREE.Vector3(player.position.x,1.18,player.position.z);
  const offset=new THREE.Vector3(Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch)+.22,Math.cos(yaw)*Math.cos(pitch)).multiplyScalar(distance);
  camera.position.copy(target).add(offset);
  camera.lookAt(target.x,target.y+0.34,target.z);
  renderer.render(scene,camera);
}
animate();
setTimeout(()=>{loading.style.opacity='0';setTimeout(()=>loading.remove(),550);},450);

addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
});
