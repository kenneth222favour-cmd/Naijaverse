# NAIJAVERSE — Browser Prototype 0.1

A first playable browser-based 3D neighbourhood prototype for NAIJAVERSE.

## What is included
- Three.js 3D scene with a small, schematic Lagos-inspired street district.
- Third-person player character.
- Keyboard movement (WASD / arrow keys).
- Drag to rotate the camera; mouse wheel to zoom.
- Touch movement buttons for mobile browsers.
- Yellow minibus props and simple street/building dressing.

**Important:** this is a visual/gameplay prototype, not a geographically accurate reconstruction of Lagos. The current buildings and road layout are procedural placeholders. The next mapping phase should use verified OpenStreetMap data and GIS processing for a selected pilot area.

## Run locally
Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Build for hosting
```bash
npm run build
```
The production website is generated in `dist/`. It can be deployed to a static hosting provider. This first prototype does not yet include accounts, multiplayer, payments, or persistent game data.

## Planned next milestones
1. Confirm pilot neighbourhood and obtain/prepare licensed geographic data.
2. Replace schematic roads with real road geometry and terrain.
3. Add vehicle entry/exit and driving controls.
4. Add Node.js multiplayer server with Socket.IO.
5. Add accounts, player persistence, economy and moderation.
6. Deploy a public test build and measure performance on Android phones.
